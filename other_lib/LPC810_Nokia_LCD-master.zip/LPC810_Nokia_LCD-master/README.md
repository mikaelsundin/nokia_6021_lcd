LPC800 Mini-Kit and Nokia 6100/6020 LCD
9-bit native SPI

http://kbiva.wordpress.com/2013/09/15/lpc800-mini-kit-and-nokia-61006020-lcd-demo/
