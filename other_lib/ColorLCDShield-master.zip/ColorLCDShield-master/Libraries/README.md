SparkFun Color LCD Shield Libraries
=================================

Libraries for use in different environments. 


Directory Contents
-------------------
* **/Arduino** - [Arduino IDE](http://www.arduino.cc/en/Main/Software) library. Currently version 1.0.1



Update Library Instructions: 
----------------------------
If you would like the most up-to-date version of the library, you must use the following commands on the command line. 

$git subtree add -P Libraries/Arduino --squash git@github.com:sparkfun/SparkFun_Color_LCD_Shield_Arduino_Library.git master

$git subtree pull -P Libraries/Arduino --squash git@github.com:sparkfun/SparkFun_Color_LCD_Shield_Arduino_Library.git master
